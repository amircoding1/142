document.addEventListener("DOMContentLoaded", function () {
    var index = 0;
    showSlides();
  
    function showSlides() {
      var i;
      var slides = document.getElementsByClassName("slider-container")[0].getElementsByTagName("img");
  
      for (i = 0; i < slides.length; i++) {
        slides[i].style.display = "none";
      }
  
      index++;
  
      if (index > slides.length) {
        index = 1;
      }
  
      slides[index - 1].style.display = "block";
      setTimeout(showSlides, 3000); // Ändere die Zeit (in Millisekunden) zwischen den Bildern nach Bedarf
    }
  });
  